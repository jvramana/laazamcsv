from django.shortcuts import render, redirect, reverse
from django.http import HttpResponseRedirect, HttpResponse
import pandas as pd
import csv
# Create your views here.

def upload(request):
    data = {}
    if "GET" == request.method:
        return render(request, 'csv_process.html', data)
    try:

        csv_file = request.FILES["csv_file"]
        if not csv_file.name.endswith('.csv'):
            data={'error' : 'File is not a CSV type'}
            return render(request, 'error_info.html', data)


        #df = pd.read_csv(csv_file)
        #data = df.to_dict()
        #print(data)
        #return render(request, 'csv_data.html', {'vd':data})
      # return df

        file_data = csv_file.read().decode("utf-8")
        lines = file_data.split("\n")
        data_dict = {}
        v_dict = {}
        i = 0
        
        for line in lines:
            if line:
                fields = line.split(",")
                v_dict[i] = {"name": fields[0], "vehicle_type": fields[1], "vehicle_no": fields[2], "chasis_no": fields[3]}
                data_dict.update(v_dict)
                i += 1
        del data_dict[0]
        print(data_dict)
        data = data_dict
        return render(request, 'csv_process.html', {'vd': data})

    except Exception as e:
        data={"error" : "Unable to upload file. Reason " + repr(e)}
        return render(request, 'error_info.html', data)

def download(request):
    if "GET" == request.method:
        try:
            response = HttpResponse(
                content_type="text/csv",
                headers={"Content-Disposition": 'attachment; filename="process_table.csv"'},
            )
            writer = csv.writer(response)
            writer.writerow(["Name", "Type", "Vehile No", "Chasis No"])
            return response

            """
            df.to_csv(r'laazaam.csv', index = False)
            csv_data = {1:['name'],2:['vehicle_no'], 3:['chasis_no'], 4:['vehicle_type']}
            df = pd.DataFrame.from_dict(csv_data)
            #return df
            df.to_csv(r'laazaam.csv', index = False)
            return redirect(upload)
            """
        except Exception as e:
            data = {"error": "Unable to download csv file. Reason " + repr(e)}
            return render(request, 'error_info.html', data)
